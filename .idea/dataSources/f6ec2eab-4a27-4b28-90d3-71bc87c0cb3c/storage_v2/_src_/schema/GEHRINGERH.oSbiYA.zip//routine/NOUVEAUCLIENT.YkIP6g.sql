create PROCEDURE nouveauClient (p_nom IN Clients.nomClient%TYPE,
                                               p_prenom IN Clients.prenomClient%TYPE,
                                               p_ville IN Clients.villeClient%TYPE) IS
   BEGIN
    INSERT INTO Clients (numeroClient, nomClient, prenomClient, villeClient)
   VALUES (seqCli.NEXTVAL, p_nom, p_prenom, p_ville) ;
   END ;
/

