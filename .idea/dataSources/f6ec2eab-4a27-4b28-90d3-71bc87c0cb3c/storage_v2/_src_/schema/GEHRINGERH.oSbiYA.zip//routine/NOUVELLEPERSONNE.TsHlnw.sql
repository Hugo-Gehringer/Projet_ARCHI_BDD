create PROCEDURE nouvellePersonne (p_nom IN Personnes.nomPersonne%TYPE,
                                              p_prenom IN Personnes.prenomPersonne%TYPE,
                                              p_ville IN Personnes.villePersonne%TYPE) IS
  BEGIN
   INSERT INTO Personnes (numPersonne, nomPersonne, prenomPersonne, villePersonne)
  VALUES (Personnes_AutoID.NEXTVAL, p_nom, p_prenom, p_ville) ;
  END ;
/

