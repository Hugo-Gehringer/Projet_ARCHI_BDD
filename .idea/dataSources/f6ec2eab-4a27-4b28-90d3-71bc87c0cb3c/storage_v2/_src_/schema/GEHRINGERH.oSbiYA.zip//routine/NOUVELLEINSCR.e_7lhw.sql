create PROCEDURE nouvelleinscr(
                                        p_numIns in Inscriptions.numInscription%TYPE,
                                        p_codeC in Clients.numClient%TYPE,
                                        p_numVoyage in Voyages.numVoyage%TYPE,
                                        p_prix in Inscriptions.montantVoyage%TYPE,
                                        p_date in Inscriptions.dateInscription%TYPE)
                                        is
BEGIN

SELECT prixActuelVoyage INTO p_prix
FROM Voyages
WHERE numVoyage=p_numVoyage;

INSERT into Inscriptions VALUES (p_numIns,p_date,p_codeC,p_numVoyage,p_prix);

END;
/

