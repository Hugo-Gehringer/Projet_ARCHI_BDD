create FUNCTION nbSalarieEmployee  (p_numSalarie IN Salaries.numSalarie%TYPE)
                                                  RETURN NUMBER IS
v_NbEmployee NUMBER;
BEGIN
SELECT Count(DISTINCT numSalarie) INTO v_NbEmployee
FROM Salaries
START WITH numSalarie=p_numSalarie
CONNECT BY PRIOR numSalarie=numSalarieChef;
RETURN v_NbEmployee;
END;
/

