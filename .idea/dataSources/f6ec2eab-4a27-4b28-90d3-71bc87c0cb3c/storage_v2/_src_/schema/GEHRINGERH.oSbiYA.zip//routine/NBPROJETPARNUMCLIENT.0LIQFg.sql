create FUNCTION NbProjetParNumClient  (p_numClient IN Clients.numClient%TYPE)
                                                RETURN NUMBER IS
v_NbProjet NUMBER;

BEGIN

SELECT Count(codeProjet) INTO v_NbProjet
FROM Projets P
WHERE numClient=p_numClient;
RETURN v_NbProjet;

END;
/

