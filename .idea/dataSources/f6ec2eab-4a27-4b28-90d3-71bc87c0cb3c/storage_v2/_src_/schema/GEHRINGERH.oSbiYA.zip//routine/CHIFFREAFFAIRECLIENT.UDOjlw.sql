create FUNCTION ChiffreAffaireClient  (p_numClient IN Clients.numeroClient%TYPE)
                                                     RETURN NUMBER IS
   v_ca NUMBER;
   BEGIN
   SELECT sum(montantAchat) INTO v_ca
   FROM Achats a
   WHERE numeroClient=p_numClient;
   RETURN v_ca;
   END;
/

